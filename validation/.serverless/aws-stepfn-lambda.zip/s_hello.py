import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='vishnuvs369',
    application_name='aws-stepfn-lambda',
    app_uid='SnjRbDbQSdb5ydz8c8',
    org_uid='11f3f00d-a4d9-4004-b8da-e694fb4e9721',
    deployment_uid='cdfdce7c-48c6-4072-9626-ca5f1034d41f',
    service_name='aws-stepfn-lambda',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.4.5',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-stepfn-lambda-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.lambda_handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
